public interface Command 
{
    public void process();
}
