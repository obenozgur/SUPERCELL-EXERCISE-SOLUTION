COMPILE WITH:

javac -cp ".:./lib/json-simple-1.1.jar" *.java 

RUN WITH:

java -cp ".:./lib/json-simple-1.1.jar" Main <input_file>